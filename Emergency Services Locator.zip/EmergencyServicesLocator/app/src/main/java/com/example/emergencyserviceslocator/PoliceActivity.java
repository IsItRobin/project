package com.example.emergencyserviceslocator;

//concern page

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PoliceActivity extends AppCompatActivity {
    Button Done, cancel,fever,nonfever;
//    here cancel is button is to cancel
//    send is to send report
//    here back is a image button to come on activity2

    public static final String NAME = "name";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_police);


        // Enable edge-to-edge display
        EdgeToEdge.enable(this);

        // Apply window insets to adjust padding
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Done = findViewById(R.id.Done);
        cancel = findViewById(R.id.cancel);
        fever = findViewById(R.id.fever_button);
        nonfever = findViewById(R.id.nonfever_button);

        Done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PoliceActivity.this, ServicesActivity.class);
                startActivity(intent); // Start the activity
            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(PoliceActivity.this, ServicesActivity.class);
                startActivity(intent); // Start the activity
            }
        });
    }
}